<!doctype html> 
<html> 
<head> 
<meta charset="UTF-8"> 
<title><?php bloginfo('name'); ?><?php wp_title(); ?></title> 

<link href="<?php bloginfo('stylesheet_url'); ?>" rel="stylesheet" type="text/css">

<script type="text/javascript" src="//use.typekit.net/qer7cfk.js"></script>
<script type="text/javascript">try{Typekit.load();}catch(e){}</script>

<meta name="generator" content="Wordpress <?php bloginfo('version') ?>" />

<link rel="alternative" type"application/rss+xml" title="RSS 2.0" href="<?php bloginfo('rss2_url'); ?>" /> 

<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" /> 

<link rel="shortcut icon" href="<?php bloginfo('template_directory'); ?>"/path/to/favicon.ico" /> 

<?php wp_head(); ?>


</head> 


<body> 
<div id="top-border-wrapper">

<div id="top-wrapper">
    <!-- start page nav --> 
  <nav class="page-nav">
    <ol> 
       <li><a href="<?php bloginfo('url'); ?>" title="home">Home</a></li>
        <?php wp_list_pages('title_li='); ?>
    </ol> 
  </nav> 
  
  <!-- end page nav --> 
  
  </div> <!-- end top wrapper -->

</div><!-- end top border wrapper -->

  <div id="wrapper"> 
  
  <div class="shim"></div>
   <!-- start page header --> 
  <header class="page-header"> 
    <h1 id="main"><?php bloginfo('name'); ?><?php wp_title(); ?></h1> 
  </header> 
  <!-- end page header --> 
  

  <!-- start feature post -->



<?php
   $featured = new WP_Query();
   $featured->query('showposts=1');
   while($featured->have_posts()) : $featured->the_post();
      $wp_query->in_the_loop = true;
      $featured_ID = $post->ID;
?>


 
  <article class="feature-article"> 
    
 <?php if (get_post_meta($post->ID, 'large_preview', true)) { ?> <div class="feature-image"><img src="<?php echo get_post_meta($post-> ID,'large_preview', true); ?>" alt="..." width="240" height="320" /></div> <?php } ?>     

    <div class="feature-content"> 
    
    <header class="feature-header"> 
      <h1><?php the_title(); ?></h1> 
      <div class="feature-meta"> 
        <p>Posted by <?php the_author_posts_link(); ?> on <?php the_time('F j, Y'); ?></p> 
      </div> 
    </header> 
    <div class="rw-ui-container rw-urid-1"></div>
	<p class="continue"><?php the_content('-Continue'); ?></p>
    <footer class="feature-footer"> 
      <p>Posted in <?php the_category(', '); ?> | Tags: <?php the_tags(' '); ?></p> 
       
    </footer>
     
</div> 

  </article> 

<?php endwhile; ?>

  <!-- end feature post -->




  
  <div class="shim"></div>  
  <!-- start basic posts -->

  <section> 
  <!-- start first post --> 

<?php if(have_posts()) :while(have_posts()) : the_post(); ?>
   <? if ($post->ID != $featured_ID) { ?>


  <article class="post-article">
   
      
    <aside class="post-leftsidebar">
    <div class="post-meta">
    <p class="date"><a><?php the_time('j'); ?></a></p>
        <p class="month"><a><?php the_time('F Y'); ?></a></p>
        <p class="author">by <?php the_author_posts_link(); ?></p> 
      </div>  
      <h4>Posted in</h4>
      <p class="catagory"><?php the_category(', '); ?></p>
      <h4>Tags:</h4>
      <p class="tags"><?php the_tags(''); ?></p> 
     
    </aside>
   
  <header class="post-header"> 
      <h1><?php the_title(); ?></h1> 
</header> 

  <div class="post-content">
    <p><?php the_content('-Continue'); ?></p>
    </div>
    
  </article> 
  
  <? } ?>
<?php endwhile ?>

<div class="shim"></div>
<!-- post the pagination -->

<div id="posts_navigation">
   <p><?php previous_posts_link(); ?>   |  
   <?php next_posts_link(); ?></p>
</div>

<?php else : ?>
<h2>Not Found</h2>
<p>Sorry... but what you are looking for is not here.</p>
<?php endif; ?>


  
  <!-- end basic posts --> 
</section>  


  <!-- start aside --> 
  <aside id="sidebar">

<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar() ) : ?>
<?php endif; ?>

<!------- search form ------>

<?php include(TEMPLATEPATH.'/searchform.php'); ?>

<!---- end-search form ----->


  <div class="sidebar-olist"> 
      <h3>Categories</h3> 
      <ol> 
      <?php wp_list_categories('title_li=&orderby=name'); ?> 
      </ol> 
    </div> 
    

    <div class="sidebar-ulist"> 
      <h3>Recent Posts</h3> 
      <ul> 
  <?php 
        $recent = new WP_Query(); 
        $recent -> query('showposts=3'); 
        while($recent -> have_posts()) : $recent -> the_post(); 
    ?> 
  <li><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"> 
    <?php the_title(); ?> 
    </a></li> 
  <?php endwhile; ?> 
</ul>
    </div>
     

    <div class="sidebar-ulist"> 
      <h3>Archives</h3> 
   <ul><?php wp_get_archives('type=monthly&limit=7'); ?></ul> 

    </div> 

  </aside> 
  <!-- end aside -->
  <div class="shim"></div>
</div> <!-- wrapper -->
  
<div id="bottom-wrapper">   
  <!-- start footer --> 

  <footer>

<div class="contact">
  <p class="title">© Juan Neri</p>
  <p><a href="http://www.neri-designs.com">neri-designs.com</a></p>
  
  <p class="title">Last Updated</p>
  <p>15 April 2013</p>
</div>
<div class="footer-meta">
  <h4>Meta</h4>
  <ol>
    <li>Site Admin</li>
    <li>Log out</li>
    <li>Entries RSS</li>
    <li>Comments RSS</li>
    <li>WordPress.org</li>
  </ol> 
</div>
  </footer> 
  <!-- end footer --> 
   
</div>

</body> 
</html>